<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboard;
use App\Http\Controllers\Kasir\DashboardController as KasirDashboard;
use App\Http\Controllers\KatalogController;
use App\Http\Controllers\Pemilik\DashboardController as PemilikDashboard;
use App\Http\Controllers\ProdukController as ProdukController;
use App\Http\Controllers\StrukController;
use App\Http\Controllers\Pemilik\AkunController;
use App\Http\Controllers\RiwayatTransaksi;

// === RUTE TAMU (Tidak Perlu Login) ===
// Tidak ada middleware 'auth' di sini
Route::get('/login', [LoginController::class, 'create'])->name('login');
Route::post('/login', [LoginController::class, 'store']);
Route::post('/logout', [LoginController::class, 'destroy'])->name('logout');


// === RUTE PENGHUNI (WAJIB LOGIN) ===
// # ALUR A: "Satpam Gerbang Utama"
// Semua rute di dalam grup ini akan dicek oleh middleware 'auth'
Route::middleware(['auth'])->group(function () {
    
    Route::get('/cetak-struk/{kode_transaksi}', [StrukController::class, 'show'])->name('transaksi.cetakStruk');
    
    // # ALUR B: "Penjaga Pintu Unit Admin"
    // Hanya user dengan role 'admin' yang boleh masuk
    Route::middleware(['role:admin'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/dashboard', [AdminDashboard::class, 'index'])->name('dashboard');
        Route::resource('produk', ProdukController::class);
    });

    // # ALUR C: "Penjaga Pintu Unit Kasir"
    // Hanya user dengan role 'kasir' yang boleh masuk
    Route::middleware(['role:kasir'])->prefix('kasir')->name('kasir.')->group(function () {
        Route::get('/dashboard', [KasirDashboard::class, 'index'])->name('dashboard');
        Route::post('/transaksi', [KatalogController::class, 'store'])->name('transaksi.store');
    });

    // # ALUR D: "Penjaga Pintu Unit Pemilik"
    // Hanya user dengan role 'pemilik' yang boleh masuk
    Route::middleware(['role:pemilik'])->prefix('pemilik')->name('pemilik.')->group(function () {
        Route::get('/dashboard', [PemilikDashboard::class, 'index'])->name('dashboard');
        Route::resource('produk', ProdukController::class);
        Route::post('/transaksi', [KatalogController::class, 'store'])->name('transaksi.store');
        Route::resource('akun', AkunController::class);
    });
}); // <-- Akhir dari grup 'auth'

Route::middleware(['auth'])->group(function () {
    // Route untuk Riwayat Transaksi
    Route::get('/riwayat-transaksi', [RiwayatTransaksi::class, 'index'])->name('riwayat-transaksi.index');
    Route::get('/riwayat-transaksi/{id}', [RiwayatTransaksi::class, 'show'])->name('riwayat-transaksi.show');
    Route::get('/riwayat-transaksi-statistik', [RiwayatTransaksi::class, 'statistik'])->name('riwayat-transaksi.statistik');
    Route::post('/riwayat-transaksi/{id}/cancel', [RiwayatTransaksi::class, 'cancel'])->name('riwayat-transaksi.cancel');
    Route::get('/riwayat-transaksi/{id}/invoice', [RiwayatTransaksi::class, 'printInvoice'])->name('riwayat-transaksi.invoice');
    Route::get('/riwayat-transaksi-export', [RiwayatTransaksi::class, 'export'])->name('riwayat-transaksi.export');
    
});