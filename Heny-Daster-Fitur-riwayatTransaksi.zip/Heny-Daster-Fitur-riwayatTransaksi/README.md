# Project Name

## Setup Instructions
1. Clone repository
2. Copy .env.example to .env
3. Run `composer install`
4. Generate app key: `php artisan key:generate`
5. Configure database in .env
6. Run migrations: `php artisan migrate